#!/bin/bash
# Halkurd v1.1 Update Script

echo "Starting Halkurd v1.1 Update..."

# 1. Update package lists
apt-get update

# 2. Install Arabic fonts, LibreOffice, and necessary tools
echo "Installing Arabic fonts and LibreOffice..."
apt-get install -y fonts-noto-core fonts-noto-naskh-arabic fonts-kacst libreoffice build-essential

# 3. Configure Arabic Locale (ar_IQ.UTF-8)
echo "Configuring Arabic locale..."
sed -i 's/# ar_IQ.UTF-8 UTF-8/ar_IQ.UTF-8 UTF-8/' /etc/locale.gen
locale-gen
# Set system default to handle Arabic correctly
update-locale LANG=ar_IQ.UTF-8

# 4. Remove Debian default wallpapers
echo "Removing Debian wallpapers..."
rm -rf /usr/share/backgrounds/*debian* /usr/share/backgrounds/*spacefun* /usr/share/backgrounds/*lines* 2>/dev/null

# 5. Install Halkurd KLC tool
echo "Installing Halkurd KLC..."
cp halkurd-klc /usr/local/bin/halkurd-klc
chmod +x /usr/local/bin/halkurd-klc

# 6. Update version number
echo "1.1" > /etc/halkurd/version

echo "Halkurd v1.1 Update Completed Successfully!"
